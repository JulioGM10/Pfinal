//
//  MapVC.swift
//  Vistas
//
//  Created by Laboratorio UNAM-Apple 08 on 05/12/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit
import MapKit

class MapVC: UIViewController {
    @IBOutlet weak var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let initialLocation = CLLocation(latitude: 37.7749, longitude: -122.431297)
        
    }
    
}
