//
//  File.swift
//  Vistas
//
//  Created by Laboratorio UNAM-Apple 08 on 05/12/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import Foundation
import Firebase
import UIKit


class HomeVC: UIViewController {
    
    override func viewDidLoad(){
    super.viewDidLoad()
    }
    
    @IBAction func HL(_ target: UIBarButtonItem){
        
        try! Auth.auth().signOut()
        self.dismiss(animated: false, completion: nil)
    }
    
}
