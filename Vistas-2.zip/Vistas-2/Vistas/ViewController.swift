//
//  ViewController.swift
//  Vistas
//
//  Created by Macbook on 11/28/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
    
    @IBOutlet weak var mapView: MKMapView!
    
    let locManager = CLLocationManager()
    var coor = CLLocationCoordinate2D()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mapView.delegate = self
        locManager.delegate = self
        locManager.requestWhenInUseAuthorization()
        locManager.desiredAccuracy = kCLLocationAccuracyBest
        
        guard let  newCoords = locManager.location?.coordinate else { return}
        
        let region = MKCoordinateRegionMakeWithDistance(newCoords, 500, 500)
        
        mapView.setRegion(region, animated: true)
        
        coor = newCoords
        
        let annotation1 = MKPointAnnotation()
        annotation1.title = "Anotacion 1"
        annotation1.subtitle = "subtitulo 1"
        annotation1.coordinate = coor
        mapView.addAnnotation(annotation1)
        
        let annotation2 = MKPointAnnotation()
        annotation2.title = "Anotacion 2"
        annotation2.subtitle = "subtitulo 2"
        annotation2.coordinate = CLLocationCoordinate2D(latitude: 37.331595, longitude: -122.031993)
        mapView.addAnnotation(annotation2)
        
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        if annotation is MKUserLocation {
            return nil
        }
        let pin = MKPinAnnotationView(annotation: annotation, reuseIdentifier: "pin")
        pin.canShowCallout = true
        pin.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        return pin
        
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl){
        
        let annView = view.annotation
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let detalleVC = storyboard.instantiateViewController(withIdentifier: "Detalle") as! DetalleViewController
        
        detalleVC.titulo = ((annView?.title)!)!
        detalleVC.subtitulo = ((annView?.subtitle)!)!
        detalleVC.latitud = (annView?.coordinate.latitude)!
        detalleVC.longitud = (annView?.coordinate.longitude)!
        
        self.navigationController!.pushViewController(detalleVC, animated: true)
        
    }
   
    
    
}
