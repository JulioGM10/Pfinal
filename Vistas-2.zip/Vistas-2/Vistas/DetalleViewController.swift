//
//  DetalleViewController.swift
//  Vistas
//
//  Created by Laboratorio UNAM-Apple 08 on 05/12/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit

class DetalleViewController: UIViewController {

    
    @IBOutlet weak var lblTitulo: UILabel!
    
    @IBOutlet weak var lblSubtitulo: UILabel!
    
    @IBOutlet weak var lblCoordenadas: UILabel!
    
    var titulo = ""
    var subtitulo = ""
    var latitud = 0.0
    var longitud = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        lblTitulo.text = titulo
        lblSubtitulo.text = subtitulo
        lblCoordenadas.text = String(format: "Lat: %.6f // Lon: %.6f", latitud, longitud)
        
    }

  

}
